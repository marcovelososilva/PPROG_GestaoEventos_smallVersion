package Main_Class;

import java.io.Serializable;

/**
 *
 * @author Marco
 */
public class workshop implements Serializable {

    /**
     * contrutor dos workshops
     */
    public void workshop() {
    }

    /**
     * to string devolve o nome da class
     * @return  string com workshop
     */
    @Override
    public String toString() {
        return "workshop";
    }

}
