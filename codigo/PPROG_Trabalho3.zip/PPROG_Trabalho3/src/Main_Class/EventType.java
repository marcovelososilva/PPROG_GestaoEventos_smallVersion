package Main_Class;

public interface EventType {
    
    public String toStringNomeTipo();
}