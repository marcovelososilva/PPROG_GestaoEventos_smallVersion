package Main_Class;

import java.io.Serializable;

public class workshop implements Serializable{

	public void workshop() {
	}

    @Override
    public String toString() {
        return "workshop";
    }
        
        
        
}